Config = {}

Config.Locale = 'en'